// ============================================================
// FocusRoom Enforcer — popup.js
// Quick-action toolbar popup. Manual start/stop when the
// backend is offline, plus live session status display.
// ============================================================

// ── DOM refs ──────────────────────────────────────────────────
const statusBadge  = document.getElementById('statusBadge');
const eloVal       = document.getElementById('eloVal');
const focusVal     = document.getElementById('focusVal');
const distractVal  = document.getElementById('distractVal');
const timerBig     = document.getElementById('timerBig');
const timerSub     = document.getElementById('timerSub');
const progressFill = document.getElementById('progressFill');
const sDot         = document.getElementById('sDot');
const sLabel       = document.getElementById('sLabel');
const btnStart     = document.getElementById('btnStart');
const btnStop      = document.getElementById('btnStop');
const btnDash      = document.getElementById('btnDash');
const toast        = document.getElementById('toast');

// ── Local state ───────────────────────────────────────────────
let selectedDuration = 45;
let timerInterval = null;
let currentState = {};

// ── Duration picker ───────────────────────────────────────────
document.querySelectorAll('.dur-pill').forEach(pill => {
  pill.addEventListener('click', () => {
    document.querySelectorAll('.dur-pill').forEach(p => p.classList.remove('selected'));
    pill.classList.add('selected');
    selectedDuration = parseInt(pill.dataset.val, 10);
  });
});

// ── Toast ─────────────────────────────────────────────────────
function showToast(msg, type = 'ok', duration = 2500) {
  toast.textContent = msg;
  toast.className = `toast show ${type}`;
  setTimeout(() => { toast.className = 'toast'; }, duration);
}

// ── Status badge ──────────────────────────────────────────────
function setStatus(mode) {
  const labels = { idle: 'Idle', active: 'Active', blocking: 'Blocking' };
  statusBadge.className = 'badge ' + mode;
  statusBadge.textContent = labels[mode] ?? mode;
}

// ── Timer display ─────────────────────────────────────────────
function startTimerTick(startTime, durationMin) {
  if (timerInterval) clearInterval(timerInterval);

  function tick() {
    const elapsed = Date.now() - startTime;
    const total = durationMin * 60000;
    const remaining = Math.max(0, total - elapsed);

    const m = Math.floor(remaining / 60000);
    const s = Math.floor((remaining % 60000) / 1000);
    timerBig.textContent = `${String(m).padStart(2,'0')}:${String(s).padStart(2,'0')}`;
    timerBig.className = 'timer-big' + (remaining < 5 * 60000 ? ' urgent' : '');
    timerSub.textContent = 'Session in progress';

    const pct = Math.min(100, (elapsed / total) * 100);
    progressFill.style.width = pct.toFixed(1) + '%';

    if (remaining === 0) clearInterval(timerInterval);
  }

  tick();
  timerInterval = setInterval(tick, 1000);
}

function stopTimerDisplay() {
  if (timerInterval) clearInterval(timerInterval);
  timerBig.textContent = '--:--';
  timerBig.className = 'timer-big idle-t';
  timerSub.textContent = 'No session running';
  progressFill.style.width = '0%';
}

// ── Apply state ───────────────────────────────────────────────
function applyState(s) {
  currentState = s;

  eloVal.textContent = s.focusElo ?? '—';
  focusVal.textContent = s.focusScore != null ? s.focusScore + '%' : '—';
  distractVal.textContent = s.distractionCount ?? 0;

  // Socket status
  const connected = s.socketConnected;
  sDot.className   = 's-dot ' + (connected ? 'on' : 'off');
  sLabel.textContent = connected
    ? 'Connected to backend'
    : 'Backend offline — manual mode';

  // Session state
  if (s.sessionActive && s.sessionStartTime) {
    setStatus('blocking');
    startTimerTick(s.sessionStartTime, s.sessionDuration ?? 45);
    btnStart.disabled = true;
    btnStop.disabled  = false;
  } else {
    setStatus('idle');
    stopTimerDisplay();
    btnStart.disabled = false;
    btnStop.disabled  = true;
  }
}

// ── Buttons ───────────────────────────────────────────────────
btnStart.addEventListener('click', async () => {
  btnStart.disabled = true;
  btnStart.textContent = '…';

  chrome.runtime.sendMessage({
    type: 'MANUAL_START',
    duration: selectedDuration,
    userId: 'local_user',
    roomId: 'local'
  }, (response) => {
    if (chrome.runtime.lastError || !response?.ok) {
      showToast('Failed to start session. Try again.', 'err');
      btnStart.disabled = false;
      btnStart.textContent = '▶ Start Session';
      return;
    }
    showToast(`Session started! ${selectedDuration}m focus block active.`, 'ok');
    // Re-fetch state to update UI
    loadState();
  });
});

btnStop.addEventListener('click', () => {
  if (!confirm('End your focus session early?')) return;

  btnStop.disabled = true;

  chrome.runtime.sendMessage({ type: 'MANUAL_STOP' }, (response) => {
    if (chrome.runtime.lastError || !response?.ok) {
      showToast('Failed to stop session.', 'err');
      btnStop.disabled = false;
      return;
    }
    showToast('Session ended. Great work!', 'ok');
    loadState();
  });
});

btnDash.addEventListener('click', () => {
  chrome.tabs.create({ url: 'newtab.html' });
  window.close();
});

// ── Background message listener ───────────────────────────────
chrome.runtime.onMessage.addListener((msg) => {
  switch (msg.type) {
    case 'TIMER_START':
      applyState({
        ...currentState,
        sessionActive: true,
        sessionStartTime: Date.now(),
        sessionDuration: msg.duration ?? 45,
        focusScore: 100,
        distractionCount: 0
      });
      break;

    case 'TIMER_END':
      applyState({
        ...currentState,
        sessionActive: false,
        focusElo: msg.newElo ?? currentState.focusElo,
        focusScore: msg.focusScore ?? currentState.focusScore
      });
      showToast('Session complete!', 'ok');
      break;

    case 'FOCUS_UPDATE':
      focusVal.textContent = (msg.score ?? currentState.focusScore) + '%';
      currentState.focusScore = msg.score;
      break;

    case 'SESSION_STATE':
      loadState(); // re-fetch full state
      break;

    case 'SOCKET_STATUS':
      sDot.className = 's-dot ' + (msg.connected ? 'on' : 'off');
      sLabel.textContent = msg.connected
        ? 'Connected to backend'
        : 'Backend offline — manual mode';
      break;

    case 'DISTRACTION_FLAG':
      if (msg.self) {
        distractVal.textContent = (parseInt(distractVal.textContent, 10) || 0) + 1;
        showToast('Distraction detected! Focus score docked.', 'err', 2000);
      }
      break;
  }
});

// ── Initial load ──────────────────────────────────────────────
function loadState() {
  chrome.runtime.sendMessage({ type: 'GET_STATE' }, (response) => {
    if (chrome.runtime.lastError || !response) return;
    applyState(response);
  });
}

loadState();

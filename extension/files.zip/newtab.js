// ============================================================
// FocusRoom Enforcer — newtab.js
// Dashboard logic: reads extension state, updates UI,
// listens to background for real-time events.
// ============================================================

const BLOCKED_SITES = [
  'YouTube', 'Instagram', 'Netflix', 'Twitter/X', 'Reddit',
  'Facebook', 'TikTok', 'Twitch', 'Discord', 'Hulu',
  'Prime Video', 'Hotstar', 'Disney+', 'Snapchat', 'Pinterest'
];

const AVATAR_COLORS = ['#7c6af7','#4fd1c5','#f6ad55','#f56565','#68d391'];

// ── DOM refs ──────────────────────────────────────────────────
const clockEl        = document.getElementById('clockDisplay');
const statusPill     = document.getElementById('statusPill');
const statusText     = document.getElementById('statusText');
const timerDisplay   = document.getElementById('timerDisplay');
const timerLabel     = document.getElementById('timerLabel');
const sessionProgress= document.getElementById('sessionProgress');
const progressPct    = document.getElementById('progressPct');
const eloNumber      = document.getElementById('eloNumber');
const eloFill        = document.getElementById('eloFill');
const focusScoreNum  = document.getElementById('focusScoreNum');
const focusBarFill   = document.getElementById('focusBarFill');
const socketDot      = document.getElementById('socketDot');
const socketLabel    = document.getElementById('socketLabel');
const roadmapList    = document.getElementById('roadmapList');
const membersList    = document.getElementById('membersList');
const blockedChips   = document.getElementById('blockedChips');
const distractionFlash = document.getElementById('distractionFlash');

// ── Local state ───────────────────────────────────────────────
let state = {
  sessionActive: false,
  sessionStartTime: null,
  sessionDuration: 45,
  focusElo: 1000,
  focusScore: null,
  roadmap: null,
  members: [],
  socketConnected: false,
  blockingActive: false
};
let timerInterval = null;

// ── Clock ─────────────────────────────────────────────────────
function updateClock() {
  const now = new Date();
  clockEl.textContent = now.toLocaleTimeString('en-IN', { hour12: false });
}
setInterval(updateClock, 1000);
updateClock();

// ── ELO ring ──────────────────────────────────────────────────
function updateEloRing(elo) {
  eloNumber.textContent = elo;
  // Map ELO 800–2000 to 0–471 (full circle circumference)
  const pct = Math.min(Math.max((elo - 800) / 1200, 0), 1);
  const circumference = 2 * Math.PI * 70; // r=70
  const offset = circumference * (1 - pct);
  eloFill.style.strokeDashoffset = offset;
}

// ── Focus score bar ───────────────────────────────────────────
function updateFocusScore(score) {
  if (score === null || score === undefined) {
    focusScoreNum.textContent = '—';
    focusBarFill.style.width = '0%';
    return;
  }
  focusScoreNum.textContent = score;
  focusBarFill.style.width = score + '%';
  focusBarFill.className = 'focus-bar-fill';
  if (score < 40) focusBarFill.classList.add('low');
  else if (score < 70) focusBarFill.classList.add('medium');
}

// ── Status pill ───────────────────────────────────────────────
function setStatus(mode) {
  // mode: 'idle' | 'active' | 'blocked'
  statusPill.className = 'status-pill ' + mode;
  const labels = { idle: 'Idle', active: 'Session Active', blocked: 'Distracted!' };
  statusText.textContent = labels[mode] || mode;
}

// ── Timer countdown ───────────────────────────────────────────
function startTimerTick() {
  if (timerInterval) clearInterval(timerInterval);
  timerInterval = setInterval(tickTimer, 1000);
  tickTimer();
}

function tickTimer() {
  if (!state.sessionActive || !state.sessionStartTime) {
    clearInterval(timerInterval);
    timerDisplay.textContent = '--:--';
    timerDisplay.className = 'timer-display idle-timer';
    timerLabel.textContent = 'No active session';
    sessionProgress.style.width = '0%';
    progressPct.textContent = '0%';
    return;
  }

  const elapsedMs = Date.now() - state.sessionStartTime;
  const totalMs = state.sessionDuration * 60 * 1000;
  const remainingMs = Math.max(0, totalMs - elapsedMs);

  const mins = Math.floor(remainingMs / 60000);
  const secs = Math.floor((remainingMs % 60000) / 1000);
  const display = `${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;

  timerDisplay.textContent = display;
  timerDisplay.className = 'timer-display' + (remainingMs < 5 * 60000 ? ' urgent' : '');
  timerLabel.textContent = 'Remaining in session';

  const pct = Math.min(100, (elapsedMs / totalMs) * 100);
  sessionProgress.style.width = pct.toFixed(1) + '%';
  progressPct.textContent = Math.round(pct) + '%';

  if (remainingMs === 0) {
    clearInterval(timerInterval);
    timerDisplay.textContent = '00:00';
    timerLabel.textContent = 'Session complete';
  }
}

// ── Roadmap ───────────────────────────────────────────────────
function renderRoadmap(roadmap, elapsedMs, totalMs) {
  if (!roadmap || !roadmap.length) {
    roadmapList.innerHTML = '<div class="roadmap-empty">No roadmap loaded</div>';
    return;
  }

  const elapsedMin = (elapsedMs ?? 0) / 60000;
  let cumulativeMin = 0;

  roadmapList.innerHTML = roadmap.map((item, i) => {
    const startMin = cumulativeMin;
    cumulativeMin += (item.duration_min ?? 15);
    const endMin = cumulativeMin;

    let phase = 'upcoming';
    if (elapsedMin >= endMin) phase = 'done';
    else if (elapsedMin >= startMin) phase = 'current';

    const timeStr = `${String(Math.floor(startMin)).padStart(2,'0')}–${String(Math.floor(endMin)).padStart(2,'0')}m`;

    return `
      <div class="roadmap-item ${phase}">
        <span class="roadmap-num">${timeStr}</span>
        <span class="roadmap-text">${item.task ?? item.description ?? 'Phase ' + (i+1)}</span>
      </div>`;
  }).join('');
}

// ── Room members ──────────────────────────────────────────────
function renderMembers(members) {
  if (!members || !members.length) {
    membersList.innerHTML = '<div class="roadmap-empty">Not in a room</div>';
    return;
  }

  membersList.innerHTML = members.map((m, i) => {
    const initials = (m.username ?? 'U').substring(0, 2).toUpperCase();
    const color = AVATAR_COLORS[i % AVATAR_COLORS.length];
    const score = m.focusScore ?? '—';

    return `
      <div class="member-row">
        <div class="member-avatar" style="background:${color}20;color:${color}">${initials}</div>
        <span class="member-name">${m.username ?? 'User ' + (i+1)}</span>
        <span class="member-score">${score}%</span>
      </div>`;
  }).join('');
}

// ── Blocked sites chips ───────────────────────────────────────
function renderBlockedChips(active) {
  blockedChips.innerHTML = BLOCKED_SITES.slice(0, 10).map(site => `
    <div class="chip ${active ? '' : 'inactive'}">${site}</div>
  `).join('');
}

// ── Socket indicator ──────────────────────────────────────────
function updateSocketUI(connected) {
  socketDot.className = 'socket-dot ' + (connected ? 'connected' : 'disconnected');
  socketLabel.textContent = connected ? 'Connected to backend' : 'Backend offline';
}

// ── Distraction flash ─────────────────────────────────────────
function flashDistraction() {
  distractionFlash.classList.add('show');
  setStatus('blocked');
  setTimeout(() => {
    distractionFlash.classList.remove('show');
    if (state.sessionActive) setStatus('active');
  }, 800);
}

// ── Apply full state ──────────────────────────────────────────
function applyState(s) {
  state = { ...state, ...s };
  updateEloRing(state.focusElo ?? 1000);
  updateSocketUI(state.socketConnected);
  renderBlockedChips(state.blockingActive || state.sessionActive);

  if (state.sessionActive) {
    setStatus('active');
    updateFocusScore(state.focusScore ?? 100);
    startTimerTick();
    const elapsed = state.sessionStartTime ? Date.now() - state.sessionStartTime : 0;
    const total = (state.sessionDuration ?? 45) * 60000;
    renderRoadmap(state.roadmap, elapsed, total);
  } else {
    setStatus('idle');
    updateFocusScore(null);
    clearInterval(timerInterval);
    timerDisplay.textContent = '--:--';
    timerDisplay.className = 'timer-display idle-timer';
    timerLabel.textContent = 'No active session';
    sessionProgress.style.width = '0%';
    progressPct.textContent = '0%';
    renderRoadmap(null);
  }

  renderMembers(state.members);
}

// ── Listen to background messages ────────────────────────────
chrome.runtime.onMessage.addListener((msg) => {
  switch (msg.type) {
    case 'TIMER_START':
      applyState({
        sessionActive: true,
        sessionStartTime: Date.now(),
        sessionDuration: msg.duration ?? 45,
        roadmap: msg.roadmap ?? null,
        focusScore: 100,
        blockingActive: true
      });
      break;

    case 'TIMER_PAUSE':
      flashDistraction();
      break;

    case 'TIMER_END':
      applyState({
        sessionActive: false,
        blockingActive: false,
        focusElo: msg.newElo ?? state.focusElo,
        focusScore: msg.focusScore ?? state.focusScore
      });
      break;

    case 'SESSION_STATE':
      applyState({ sessionActive: msg.active, blockingActive: msg.active });
      break;

    case 'FOCUS_UPDATE':
      state.focusScore = msg.score ?? state.focusScore;
      updateFocusScore(state.focusScore);
      if (msg.reason && msg.reason !== 'ok') flashDistraction();
      break;

    case 'ROOM_STATE':
      state.members = msg.members ?? [];
      renderMembers(state.members);
      break;

    case 'DISTRACTION_FLAG':
      if (msg.self) flashDistraction();
      break;

    case 'SOCKET_STATUS':
      state.socketConnected = msg.connected;
      updateSocketUI(msg.connected);
      break;
  }
});

// ── Initial load ──────────────────────────────────────────────
chrome.runtime.sendMessage({ type: 'GET_STATE' }, (response) => {
  if (chrome.runtime.lastError || !response) return;
  applyState(response);
});

// Refresh state every 30 seconds (in case messages were missed)
setInterval(() => {
  chrome.runtime.sendMessage({ type: 'GET_STATE' }, (response) => {
    if (!chrome.runtime.lastError && response) {
      // Only update non-real-time fields to avoid timer jitter
      updateEloRing(response.focusElo ?? state.focusElo);
      updateSocketUI(response.socketConnected);
      renderBlockedChips(response.blockingActive || response.sessionActive);
    }
  });
}, 30000);
